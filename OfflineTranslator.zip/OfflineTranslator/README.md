# Offline Translator (Android)

A starter Android app with three translation modes, built on **Google ML Kit**
(the on-device models that actually make offline translation possible):

- **Languages tab** — download/delete on-device translation packs (~30MB each). Needs internet once; translation works with no connection afterward.
- **Text tab** — type text, translate offline.
- **Voice tab** — speak, get translated text spoken back. *(Caveat: true offline speech-to-text depends on the phone having an offline speech pack installed in system settings — see note in-app.)*
- **Camera tab** — take a photo, on-device OCR reads the text, then translates it offline.

## Get the app automatically on every GitHub push

This project includes a GitHub Actions workflow (`.github/workflows/build.yml`)
that builds the APK on GitHub's own servers — you don't need Android Studio
installed at all for this path.

**One-time setup:**
1. Create a new repo on GitHub (public or private, either works).
2. Push this whole `OfflineTranslator` folder to it:
   ```
   cd OfflineTranslator
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```
3. On GitHub, go to the **Actions** tab — you'll see "Build APK" running automatically (takes ~2-4 minutes the first time).

**Getting the app after that, every time:**
- Go to your repo's **Releases** page (right sidebar, or `github.com/YOU/YOUR-REPO/releases`) — there's always a **"Latest build"** release with `app-debug.apk` attached.
- Open that link on your Android phone (or download on desktop and transfer it over), tap the APK, and install it. You'll need to allow "Install unknown apps" for your browser/file manager the first time — Android will prompt you for this.
- Every time you push new code, that Release gets automatically overwritten with the newest build — same link, always current.

You can also grab the APK from the **Actions** tab under a specific run's "Artifacts" section if you'd rather not use Releases, but the Releases link is more convenient since it never expires and doesn't require a GitHub login to download.

## How to open and run it locally instead (if you have Android Studio)

1. Install **Android Studio** (Koala or newer) if you don't have it: https://developer.android.com/studio
2. Open Android Studio → **Open** → select this `OfflineTranslator` folder.
3. Let Gradle sync (first sync downloads dependencies — needs internet, one time).
4. Connect a physical Android phone (USB debugging on) or start an emulator with **Play Store image** (ML Kit needs Google Play Services).
5. Click **Run ▶**.

## Try it

1. Go to the **Languages** tab, download English + one other language.
2. Go to **Text**, type something, hit Translate.
3. Turn on Airplane Mode and try again — it still works. That's the whole point.

## What's simplified in this starter (next steps if you want to keep building)

- **Camera mode** takes a still photo rather than live-overlay translation (like Google Translate's real-time camera mode). Real-time overlay is very doable with CameraX `ImageAnalysis` + ML Kit's streaming API, but it's a meaningfully bigger chunk of work — happy to build that next if you want it.
- **Language list** covers ~20 common languages; ML Kit actually supports ~59 — easy to extend, just add more entries to `Languages.kt`.
- **Non-Latin OCR** (Chinese/Japanese/Korean/Devanagari source text) needs ML Kit's script-specific text recognizers — currently wired for Latin script only.
- No app icon, splash screen, or polish — functional, not pretty yet.

## Project structure

```
OfflineTranslator/
  app/
    build.gradle.kts          # dependencies: ML Kit, CameraX, Compose
    src/main/
      AndroidManifest.xml     # camera/mic/internet permissions
      java/.../offlinetranslator/
        MainActivity.kt       # all 4 screens (Compose UI)
        TranslatorViewModel.kt# translation + model download logic
        VoiceHelper.kt        # speech-to-text / text-to-speech
        OcrHelper.kt          # on-device text recognition
        Languages.kt          # supported language list
```

## A note on how I built this

I can't compile or run an Android build here (no Android SDK / no network
in this environment), so this hasn't been build-tested by a compiler —
I've written it carefully against the current ML Kit / CameraX / Compose
APIs, but when you first open it in Android Studio, treat any red
squiggles or Gradle sync errors as normal first-pass fixes, not signs
something is fundamentally wrong. Paste me any error message and I'll
fix it fast.
