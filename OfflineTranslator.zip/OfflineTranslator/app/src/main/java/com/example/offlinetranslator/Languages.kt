package com.example.offlinetranslator

import com.google.mlkit.nl.translate.TranslateLanguage

/**
 * A friendly-name list of languages ML Kit can translate on-device.
 * ML Kit ships ~59 languages; this is a practical subset — add more
 * TranslateLanguage.* constants here if you need them.
 */
data class LanguageOption(val displayName: String, val mlKitCode: String)

val SUPPORTED_LANGUAGES = listOf(
    LanguageOption("English", TranslateLanguage.ENGLISH),
    LanguageOption("Spanish", TranslateLanguage.SPANISH),
    LanguageOption("French", TranslateLanguage.FRENCH),
    LanguageOption("German", TranslateLanguage.GERMAN),
    LanguageOption("Italian", TranslateLanguage.ITALIAN),
    LanguageOption("Portuguese", TranslateLanguage.PORTUGUESE),
    LanguageOption("Russian", TranslateLanguage.RUSSIAN),
    LanguageOption("Chinese", TranslateLanguage.CHINESE),
    LanguageOption("Japanese", TranslateLanguage.JAPANESE),
    LanguageOption("Korean", TranslateLanguage.KOREAN),
    LanguageOption("Arabic", TranslateLanguage.ARABIC),
    LanguageOption("Hindi", TranslateLanguage.HINDI),
    LanguageOption("Bengali", TranslateLanguage.BENGALI),
    LanguageOption("Dutch", TranslateLanguage.DUTCH),
    LanguageOption("Turkish", TranslateLanguage.TURKISH),
    LanguageOption("Vietnamese", TranslateLanguage.VIETNAMESE),
    LanguageOption("Thai", TranslateLanguage.THAI),
    LanguageOption("Polish", TranslateLanguage.POLISH),
    LanguageOption("Swedish", TranslateLanguage.SWEDISH),
    LanguageOption("Greek", TranslateLanguage.GREEK),
)
