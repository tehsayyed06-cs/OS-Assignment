package com.example.offlinetranslator

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * On-device text recognition (OCR). This runs fully offline — the Latin
 * text recognizer model ships with the app, no download needed.
 *
 * Note: ML Kit's on-device OCR works great for Latin-script languages.
 * For Chinese/Japanese/Korean or Devanagari script source photos you'd
 * swap in TextRecognizerOptionsChinese / Japanese / Korean / Devanagari
 * from the mlkit text-recognition extension libraries.
 */
object OcrHelper {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognizeText(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        val result = recognizer.process(image).await()
        return result.text
    }
}
