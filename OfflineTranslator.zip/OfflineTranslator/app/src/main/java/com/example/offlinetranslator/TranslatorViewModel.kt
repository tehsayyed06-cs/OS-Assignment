package com.example.offlinetranslator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Central place for everything translation-related:
 *  - which language packs are downloaded on this device
 *  - downloading / deleting language packs
 *  - running an offline translation once both packs exist
 *
 * ML Kit's Translator only supports ONE language pair at a time, so we
 * build a new Translator whenever the source/target pair changes, and
 * close the old one to free memory.
 */
class TranslatorViewModel : ViewModel() {

    private val modelManager = RemoteModelManager.getInstance()

    private val _downloadedCodes = MutableStateFlow<Set<String>>(emptySet())
    val downloadedCodes: StateFlow<Set<String>> = _downloadedCodes

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage

    private val _translatedText = MutableStateFlow("")
    val translatedText: StateFlow<String> = _translatedText

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy

    private var activeTranslator: Translator? = null
    private var activeSource: String? = null
    private var activeTarget: String? = null

    init {
        refreshDownloadedModels()
    }

    /** Checks which language models are already on the device. */
    fun refreshDownloadedModels() {
        viewModelScope.launch {
            try {
                val models = modelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
                _downloadedCodes.value = models.map { it.language }.toSet()
            } catch (e: Exception) {
                _statusMessage.value = "Couldn't read downloaded models: ${e.message}"
            }
        }
    }

    /** Downloads a language pack. Requires internet ONLY for this step. */
    fun downloadLanguage(code: String, requireWifi: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            _statusMessage.value = "Downloading $code..."
            try {
                val model = TranslateRemoteModel.Builder(code).build()
                val conditions = DownloadConditions.Builder().apply {
                    if (requireWifi) requireWifi()
                }.build()
                modelManager.download(model, conditions).await()
                _statusMessage.value = "$code downloaded — ready for offline use."
                refreshDownloadedModels()
            } catch (e: Exception) {
                _statusMessage.value = "Download failed: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun deleteLanguage(code: String) {
        viewModelScope.launch {
            try {
                val model = TranslateRemoteModel.Builder(code).build()
                modelManager.deleteDownloadedModel(model).await()
                refreshDownloadedModels()
            } catch (e: Exception) {
                _statusMessage.value = "Delete failed: ${e.message}"
            }
        }
    }

    /**
     * Translates text fully offline. Both [sourceCode] and [targetCode]
     * must already be downloaded (English is bundled as a pivot language
     * by ML Kit automatically when translating between two non-English
     * languages, but you should still download it for reliability).
     */
    fun translate(text: String, sourceCode: String, targetCode: String) {
        if (text.isBlank()) {
            _translatedText.value = ""
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val translator = getOrCreateTranslator(sourceCode, targetCode)
                val result = translator.translate(text).await()
                _translatedText.value = result
            } catch (e: Exception) {
                _statusMessage.value = "Translation failed: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    private fun getOrCreateTranslator(sourceCode: String, targetCode: String): Translator {
        if (activeTranslator != null && activeSource == sourceCode && activeTarget == targetCode) {
            return activeTranslator!!
        }
        activeTranslator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceCode)
            .setTargetLanguage(targetCode)
            .build()
        val translator = Translation.getClient(options)
        activeTranslator = translator
        activeSource = sourceCode
        activeTarget = targetCode
        return translator
    }

    override fun onCleared() {
        super.onCleared()
        activeTranslator?.close()
    }
}
