package com.example.offlinetranslator

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

class MainActivity : ComponentActivity() {

    private val viewModel: TranslatorViewModel by viewModels()
    private lateinit var voiceHelper: VoiceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voiceHelper = VoiceHelper(this)
        voiceHelper.initTextToSpeech()

        setContent {
            MaterialTheme {
                AppRoot(viewModel = viewModel, voiceHelper = voiceHelper)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceHelper.shutdown()
    }
}

private enum class Tab(val label: String) {
    LANGUAGES("Languages"),
    TEXT("Text"),
    VOICE("Voice"),
    CAMERA("Camera")
}

@Composable
private fun AppRoot(viewModel: TranslatorViewModel, voiceHelper: VoiceHelper) {
    var selectedTab by remember { mutableStateOf(Tab.TEXT) }

    // Shared source/target language selection across all tabs.
    var sourceLang by remember { mutableStateOf(SUPPORTED_LANGUAGES[0]) } // English
    var targetLang by remember { mutableStateOf(SUPPORTED_LANGUAGES[1]) } // Spanish

    Scaffold(
        topBar = { TopAppBar(title = { Text("Offline Translator") }) },
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        label = { Text(tab.label) },
                        icon = {}
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                Tab.LANGUAGES -> LanguagesScreen(viewModel)
                Tab.TEXT -> TextTranslateScreen(viewModel, sourceLang, targetLang, { sourceLang = it }, { targetLang = it })
                Tab.VOICE -> VoiceTranslateScreen(viewModel, voiceHelper, sourceLang, targetLang, { sourceLang = it }, { targetLang = it })
                Tab.CAMERA -> CameraTranslateScreen(viewModel, sourceLang, targetLang, { sourceLang = it }, { targetLang = it })
            }
        }
    }
}

// ---------- Shared language picker row ----------

@Composable
private fun LanguagePickerRow(
    sourceLang: LanguageOption,
    targetLang: LanguageOption,
    onSourceChange: (LanguageOption) -> Unit,
    onTargetChange: (LanguageOption) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        LanguageDropdown("From", sourceLang, Modifier.weight(1f)) { onSourceChange(it) }
        Spacer(Modifier.width(8.dp))
        LanguageDropdown("To", targetLang, Modifier.weight(1f)) { onTargetChange(it) }
    }
}

@Composable
private fun LanguageDropdown(
    label: String,
    selected: LanguageOption,
    modifier: Modifier = Modifier,
    onSelect: (LanguageOption) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected.displayName}")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            SUPPORTED_LANGUAGES.forEach { option ->
                DropdownMenuItem(text = { Text(option.displayName) }, onClick = {
                    onSelect(option)
                    expanded = false
                })
            }
        }
    }
}

// ---------- Languages / download screen ----------

@Composable
private fun LanguagesScreen(viewModel: TranslatorViewModel) {
    val downloaded by viewModel.downloadedCodes.collectAsState()
    val status by viewModel.statusMessage.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "Download a language pack once (needs internet). After that, translation for that language works with no connection at all.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        if (status.isNotBlank()) {
            Text(status, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
        }
        if (isBusy) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn {
            items(SUPPORTED_LANGUAGES) { lang ->
                val isDownloaded = downloaded.contains(lang.mlKitCode)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(lang.displayName, style = MaterialTheme.typography.bodyLarge)
                    if (isDownloaded) {
                        TextButton(onClick = { viewModel.deleteLanguage(lang.mlKitCode) }) {
                            Text("Delete")
                        }
                    } else {
                        Button(onClick = { viewModel.downloadLanguage(lang.mlKitCode, requireWifi = false) }) {
                            Text("Download")
                        }
                    }
                }
            }
        }
    }
}

// ---------- Text translation screen ----------

@Composable
private fun TextTranslateScreen(
    viewModel: TranslatorViewModel,
    sourceLang: LanguageOption,
    targetLang: LanguageOption,
    onSourceChange: (LanguageOption) -> Unit,
    onTargetChange: (LanguageOption) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val translated by viewModel.translatedText.collectAsState()
    val isBusy by viewModel.isBusy.collectAsState()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LanguagePickerRow(sourceLang, targetLang, onSourceChange, onTargetChange)
        OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            label = { Text("Enter text") },
            modifier = Modifier.fillMaxWidth().height(140.dp)
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { viewModel.translate(inputText, sourceLang.mlKitCode, targetLang.mlKitCode) },
            enabled = !isBusy
        ) { Text("Translate") }
        Spacer(Modifier.height(16.dp))
        Text("Translation:", style = MaterialTheme.typography.labelLarge)
        Text(translated, style = MaterialTheme.typography.headlineSmall)
    }
}

// ---------- Voice translation screen ----------

@Composable
private fun VoiceTranslateScreen(
    viewModel: TranslatorViewModel,
    voiceHelper: VoiceHelper,
    sourceLang: LanguageOption,
    targetLang: LanguageOption,
    onSourceChange: (LanguageOption) -> Unit,
    onTargetChange: (LanguageOption) -> Unit
) {
    val context = LocalContext.current
    var heardText by remember { mutableStateOf("") }
    val translated by viewModel.translatedText.collectAsState()

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!text.isNullOrBlank()) {
            heardText = text
            viewModel.translate(text, sourceLang.mlKitCode, targetLang.mlKitCode)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            speechLauncher.launch(voiceHelper.buildRecognizerIntent(sourceLang.mlKitCode))
        }
    }

    LaunchedEffect(translated) {
        if (translated.isNotBlank()) {
            voiceHelper.speak(translated, targetLang.mlKitCode)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LanguagePickerRow(sourceLang, targetLang, onSourceChange, onTargetChange)
        Spacer(Modifier.height(24.dp))
        Text(
            "Offline voice recognition depends on your phone having an " +
                "offline speech pack installed for this language (Settings > " +
                "System > Languages & input > Voice input). Otherwise it will " +
                "quietly use the network.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            val hasPermission = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                speechLauncher.launch(voiceHelper.buildRecognizerIntent(sourceLang.mlKitCode))
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }) {
            Text("🎤 Speak")
        }
        Spacer(Modifier.height(24.dp))
        Text("Heard: $heardText", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Text("Translation:", style = MaterialTheme.typography.labelLarge)
        Text(translated, style = MaterialTheme.typography.headlineSmall)
    }
}

// ---------- Camera translation screen ----------

@Composable
private fun CameraTranslateScreen(
    viewModel: TranslatorViewModel,
    sourceLang: LanguageOption,
    targetLang: LanguageOption,
    onSourceChange: (LanguageOption) -> Unit,
    onTargetChange: (LanguageOption) -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission = granted }

    var recognizedText by remember { mutableStateOf("") }
    val translated by viewModel.translatedText.collectAsState()
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LanguagePickerRow(sourceLang, targetLang, onSourceChange, onTargetChange)

        if (!hasCameraPermission) {
            Button(onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }) {
                Text("Grant camera permission")
            }
            return@Column
        }

        AndroidViewCameraPreview(
            modifier = Modifier.fillMaxWidth().height(320.dp),
            onImageCaptureReady = { imageCapture = it }
        )

        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val capture = imageCapture ?: return@Button
            capture.takePicture(
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val bitmap = imageProxyToBitmap(image)
                        image.close()
                        if (bitmap != null) {
                            coroutineScope.launch {
                                val text = try {
                                    OcrHelper.recognizeText(bitmap)
                                } catch (e: Exception) {
                                    "OCR failed: ${e.message}"
                                }
                                recognizedText = text
                                viewModel.translate(text, sourceLang.mlKitCode, targetLang.mlKitCode)
                            }
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        recognizedText = "Capture failed: ${exception.message}"
                    }
                }
            )
        }) { Text("📷 Capture & Translate") }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("Detected text:", style = MaterialTheme.typography.labelLarge)
            Text(recognizedText)
            Spacer(Modifier.height(12.dp))
            Text("Translation:", style = MaterialTheme.typography.labelLarge)
            Text(translated, style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun AndroidViewCameraPreview(
    modifier: Modifier = Modifier,
    onImageCaptureReady: (ImageCapture) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    androidx.compose.ui.viewinterop.AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val imageCapture = ImageCapture.Builder().build()
                onImageCaptureReady(imageCapture)
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageCapture
                    )
                } catch (e: Exception) {
                    // Camera binding failed — surface via logcat during development.
                    e.printStackTrace()
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        }
    )
}

/** Converts a captured JPEG ImageProxy into a Bitmap for ML Kit. */
private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    val buffer: ByteBuffer = image.planes[0].buffer
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
}
