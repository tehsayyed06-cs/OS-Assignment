package com.example.offlinetranslator

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Wraps Android's built-in speech recognizer and text-to-speech engine.
 *
 * IMPORTANT CAVEAT (tell your users this): Android's SpeechRecognizer only
 * runs fully offline if the user has downloaded an offline speech
 * recognition pack for that language under
 * Settings > System > Languages & input > Voice input > offline speech
 * recognition. We can prompt Android to prefer offline, but we can't force
 * it — if no offline pack exists, Android will silently use the network.
 */
class VoiceHelper(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun initTextToSpeech(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) onReady()
        }
    }

    fun speak(text: String, languageCode: String) {
        if (!ttsReady || text.isBlank()) return
        val locale = Locale(languageCode)
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    fun buildRecognizerIntent(languageCode: String): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
            // Ask Android to prefer an on-device recognizer when one is available.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
    }

    fun isRecognitionAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(context)

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
